export interface PatientInfo {
    id: string;
    firstName: string;
    lastname: string;
    email: string;
    phnum: string;
    reasons: string;
    dob: string;
    diagnosis: string;
}
