export class Profile {
    idNum: string;
    details: string;
}
